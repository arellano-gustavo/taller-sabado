RUTA=.

docker stop zen
docker rm zen

docker run -d \
-p 8085:80 \
--name=zen \
-v $RUTA:/usr/share/nginx/html \
nginx 
