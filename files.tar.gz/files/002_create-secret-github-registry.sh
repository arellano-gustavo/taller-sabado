# create a secret for access the github registry
microk8s.kubectl create secret docker-registry mygithubregistrykey \
  --docker-server=ghcr.io \
  --docker-username=capacitacion-ultra \
  --docker-password=ghp_msnVqu0R9h3IcdpBy8aCJPWgPRIDl8255MC \
  --docker-email=generacion3.ultrasist@gmail.com
