# create a secret for access the github registry
microk8s.kubectl create secret docker-registry mygithubregistrykey \
  --docker-server=ghcr.io \
  --docker-username=arellano-gustavo \
  --docker-password=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 \
  --docker-email=arellano.gustavo@gmail.com
