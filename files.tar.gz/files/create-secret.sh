# create a secret for access the github registry
microk8s.kubectl create secret docker-registry mygithubregistrykey \
  --docker-server=ghcr.io \
  --docker-username=arellano-gustavo \
  --docker-password=ghp_XXXXXXXXXXXXXX \
  --docker-email=arellano.gustavo@gmail.com
