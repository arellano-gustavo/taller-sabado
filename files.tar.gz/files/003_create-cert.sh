microk8s.kubectl create secret tls nombre-secreto \
  --cert=/home/ubuntu/files/certs/cert.pem \
  --key=/home/ubuntu/files/certs/privkey.pem


