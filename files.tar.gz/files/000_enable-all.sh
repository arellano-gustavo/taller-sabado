microk8s status --wait-ready
microk8s enable dashboard
microk8s enable dns
microk8s enable registry
microk8s enable observability
microk8s enable ingress
echo "done !!!"
